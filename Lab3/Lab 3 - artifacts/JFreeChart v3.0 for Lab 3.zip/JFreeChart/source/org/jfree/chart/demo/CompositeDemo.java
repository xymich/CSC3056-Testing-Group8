package org.jfree.chart.demo;

public class CompositeDemo {

	
	public static void main(String[] args)
	{
		BarChartDemo1.main(args);
		PieChartDemo1.main(args);
		TimeSeriesChartDemo1.main(args);
	}
	
}
